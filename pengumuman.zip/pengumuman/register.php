<?php
$conn = mysqli_connect("localhost", "root", "", "pengumuman_db");

if(isset($_POST['daftar'])){

    $username = $_POST['username'];
    $password = $_POST['password'];

    mysqli_query($conn, "INSERT INTO users(username,password,role)
    VALUES('$username','$password','user')");

    echo "
    <script>
        alert('Pendaftaran berhasil');
        window.location='login.php';
    </script>
    ";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>

    <style>
        body{
            font-family: Arial;
            background: linear-gradient(135deg,#4f46e5,#9333ea);
            height:100vh;
            display:flex;
            justify-content:center;
            align-items:center;
        }

        .card{
            background:white;
            width:350px;
            padding:30px;
            border-radius:20px;
            box-shadow:0 10px 30px rgba(0,0,0,0.2);
        }

        h2{
            text-align:center;
        }

        input{
            width:100%;
            padding:12px;
            margin-top:10px;
            border-radius:10px;
            border:1px solid #ccc;
        }

        button{
            width:100%;
            padding:12px;
            margin-top:15px;
            border:none;
            background:#4f46e5;
            color:white;
            border-radius:10px;
            font-size:16px;
            cursor:pointer;
        }

        a{
            text-decoration:none;
        }
    </style>
</head>
<body>

<div class="card">
    <h2>Daftar Akun</h2>

    <form method="POST">
        <input type="text" name="username" placeholder="Username" required>

        <input type="password" name="password" placeholder="Password" required>

        <button type="submit" name="daftar">
            Daftar
        </button>
    </form>

    <p align="center">
        Sudah punya akun?
        <a href="login.php">Login</a>
    </p>
</div>

</body>
</html>