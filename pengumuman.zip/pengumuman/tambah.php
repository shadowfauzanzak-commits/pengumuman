<?php
session_start();
include "koneksi.php";

// Hanya admin yang boleh mengakses
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    die("Akses ditolak!");
}

if (isset($_POST['simpan'])) {

    $judul = $_POST['judul'];
    $isi = $_POST['isi'];

    $gambar = "";

    if ($_FILES['gambar']['name'] != "") {

        $gambar = time() . "_" . $_FILES['gambar']['name'];

        move_uploaded_file(
            $_FILES['gambar']['tmp_name'],
            "uploads/" . $gambar
        );
    }

    mysqli_query($koneksi, "
        INSERT INTO pengumuman(judul, isi, gambar)
        VALUES('$judul','$isi','$gambar')
    ");

    header("Location:index.php");
}
?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<title>Tambah Pengumuman</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial;
}

body{

    height:100vh;

    display:flex;

    justify-content:center;

    align-items:center;

    background:
    linear-gradient(rgba(0,0,0,.55),
    rgba(0,0,0,.55)),
    url("https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=1600&q=80");

    background-size:cover;

    background-position:center;

}

.box{

    width:500px;

    padding:35px;

    border-radius:20px;

    background:rgba(255,255,255,.12);

    backdrop-filter:blur(12px);

    box-shadow:0 10px 40px rgba(0,0,0,.4);

    color:white;

}

h2{

    text-align:center;

    margin-bottom:25px;

}

input[type=text],
textarea{

    width:100%;

    padding:14px;

    margin-top:10px;

    margin-bottom:18px;

    border:none;

    border-radius:10px;

    outline:none;

    font-size:16px;

}

input[type=file]{

    width:100%;

    margin-bottom:20px;

    color:white;

}

button{

    width:100%;

    padding:14px;

    border:none;

    border-radius:10px;

    background:#4f46e5;

    color:white;

    font-size:17px;

    cursor:pointer;

    transition:.3s;

}

button:hover{

    background:#7c3aed;

    transform:scale(1.02);

}

a{

    display:block;

    text-align:center;

    margin-top:15px;

    color:white;

    text-decoration:none;

}

</style>

</head>

<body>

<div class="box">

<h2>

<i class="fa-solid fa-circle-plus"></i>

Tambah Pengumuman

</h2>

<form method="POST" enctype="multipart/form-data">

<input
type="text"
name="judul"
placeholder="Masukkan Judul"
required>

<textarea
name="isi"
rows="6"
placeholder="Masukkan Isi Pengumuman"
required></textarea>

<input
type="file"
name="gambar"
accept="image/*">

<button
type="submit"
name="simpan">

<i class="fa-solid fa-floppy-disk"></i>

Simpan

</button>

</form>

<a href="index.php">

<i class="fa-solid fa-arrow-left"></i>

Kembali

</a>

</div>

</body>

</html>