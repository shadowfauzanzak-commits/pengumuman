<?php
session_start();
include "koneksi.php";

// Hanya admin yang boleh menghapus
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    die("Akses ditolak!");
}

$id = $_GET['id'];

$query = mysqli_query($koneksi, "DELETE FROM pengumuman WHERE id='$id'");

if ($query) {
    header("Location: index.php");
    exit;
} else {
    echo "Gagal menghapus data: " . mysqli_error($koneksi);
}
?>