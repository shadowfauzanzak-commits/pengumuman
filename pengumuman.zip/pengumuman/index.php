<?php
session_start();
include "koneksi.php";

// Cek login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Ambil data pengumuman
$query = mysqli_query($koneksi, "SELECT * FROM pengumuman ORDER BY id DESC");

if (!$query) {
    die("Query Error: " . mysqli_error($koneksi));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Aplikasi Pengumuman</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

body{
    margin:0;
    font-family:Arial,sans-serif;
    background:#0f172a;
    color:white;
}

.header{
    background:linear-gradient(90deg,#4f46e5,#9333ea);
    padding:25px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.logo h1{
    margin:0;
    font-size:45px;
}

.logo p{
    margin:0;
    color:yellow;
    letter-spacing:5px;
}

.menu{
    display:flex;
    gap:10px;
}

.btn{
    padding:12px 22px;
    border-radius:10px;
    text-decoration:none;
    font-weight:bold;
}

.tambah{
    background:white;
    color:black;
}

.logout{
    background:#ef4444;
    color:white;
}

.container{
    width:90%;
    margin:auto;
    margin-top:30px;
}

.card{

    background:rgba(255,255,255,.08);
    backdrop-filter:blur(8px);

    border-radius:20px;
    padding:25px;

    margin-bottom:25px;

    box-shadow:0 0 20px rgba(0,0,0,.3);
}

.card h2{

    margin-top:10px;
}

.card img{

    width:100%;
    max-height:400px;

    object-fit:cover;

    border-radius:15px;

    margin-bottom:15px;
}

.info{

    display:flex;

    justify-content:space-between;

    align-items:center;

    margin-top:15px;
}

.aksi{

    margin-top:15px;
}

.edit{

    background:orange;

    color:black;

    padding:10px 20px;

    border-radius:10px;

    text-decoration:none;

    font-weight:bold;
}

.hapus{

    background:red;

    color:white;

    padding:10px 20px;

    border-radius:10px;

    text-decoration:none;

    font-weight:bold;
}

</style>

</head>

<body>

<div class="header">

<div class="logo">

<h1><i class="fa-solid fa-bullhorn"></i> Aplikasi Pengumuman</h1>

<p>SMK N 1 SANDEN</p>

</div>

<div class="menu">

<?php if(isset($_SESSION['role']) && $_SESSION['role']=="admin"){ ?>

<a href="tambah.php" class="btn tambah">
<i class="fa fa-plus"></i> Tambah
</a>

<?php } ?>

<a href="logout.php" class="btn logout">

<i class="fa fa-right-from-bracket"></i>

Logout

</a>

</div>

</div>

<div class="container">

<h1>

<i class="fa-solid fa-clipboard-list"></i>

Daftar Pengumuman

</h1>

<?php while($data=mysqli_fetch_assoc($query)){ ?>

<div class="card">

<?php

if(!empty($data['gambar']) && file_exists("uploads/".$data['gambar'])){

?>

<img src="uploads/<?php echo $data['gambar']; ?>">

<?php } ?>

<h2>

<?php echo htmlspecialchars($data['judul']); ?>

</h2>

<p>

<?php echo nl2br(htmlspecialchars($data['isi'])); ?>

</p>

<div class="info">

<small>

<i class="fa-solid fa-clock"></i>

<?php echo $data['tanggal']; ?>

</small>

</div>

<?php if(isset($_SESSION['role']) && $_SESSION['role']=="admin"){ ?>

<div class="aksi">

<a class="edit"

href="edit.php?id=<?php echo $data['id']; ?>">

<i class="fa-solid fa-pen"></i>

Edit

</a>

<a class="hapus"

onclick="return confirm('Yakin ingin menghapus?')"

href="hapus.php?id=<?php echo $data['id']; ?>">

<i class="fa-solid fa-trash"></i>

Hapus

</a>

</div>

<?php } ?>

</div>

<?php } ?>

</div>

</body>
</html>