<?php
// Isi dari file koneksi.php

$host = "localhost";
$user = "root";
$pass = "";
$db   = "pengumuman_db"; // Sesuaikan dengan nama database kamu

// Pastikan nama variabelnya adalah $koneksi
$koneksi = mysqli_connect($host, $user, $pass, $db);

if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>