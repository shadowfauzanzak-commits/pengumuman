<?php
session_start();

$conn = mysqli_connect("localhost","root","","pengumuman_db");

if(!$conn){
    die("Koneksi database gagal");
}

if(isset($_POST['login'])){

    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = mysqli_query($conn,
    "SELECT * FROM users
    WHERE username='$username'
    AND password='$password'");

    if(mysqli_num_rows($query) > 0){

        $data = mysqli_fetch_assoc($query);

        // SESSION LOGIN
        $_SESSION['login'] = true;
        $_SESSION['id'] = $data['id'];
        $_SESSION['username'] = $data['username'];
        $_SESSION['role'] = $data['role'];

        // LOGIN BERDASARKAN ROLE
        if($data['role'] == 'admin'){

            header("Location:index.php");

        } else if($data['role'] == 'user'){

            header("Location:index.php");

        }

        exit;

    } else {

        $error = "Username atau Password salah!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Login</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial;
}

body{
    height:100vh;

    background:
    linear-gradient(rgba(0,0,0,0.5),
    rgba(0,0,0,0.5)),
    url('https://images.unsplash.com/photo-1523050854058-8df90110c9f1');

    background-size:cover;
    background-position:center;

    display:flex;
    justify-content:center;
    align-items:center;
}

.login-box{

    width:400px;

    background:rgba(0, 238, 255, 1);

    backdrop-filter:blur(12px);

    border:1px solid rgba(0, 0, 0, 1);

    padding:40px;

    border-radius:25px;

    box-shadow:0 10px 30px rgba(0,0,0,0.4);

}

.logo{

    text-align:center;
    color:white;
    margin-bottom:25px;

}

.logo i{

    font-size:70px;
    margin-bottom:15px;

}

.logo h1{

    font-size:40px;

}

.logo p{

    color:yellow;
    letter-spacing:3px;

}

.input-box{

    position:relative;
    margin-bottom:20px;

}

.input-box input{

    width:100%;
    padding:15px 45px;

    border:none;
    outline:none;

    border-radius:12px;

    font-size:16px;

}

.input-box i{

    position:absolute;
    left:15px;
    top:17px;
    color:#555;

}

.btn-login{

    width:100%;

    padding:15px;

    border:none;

    border-radius:12px;

    background:linear-gradient(135deg,#4f46e5,#9333ea);

    color:white;

    font-size:17px;
    font-weight:bold;

    cursor:pointer;

    transition:0.3s;

}

.btn-login:hover{

    transform:scale(1.03);

}

.error{

    background:#ef4444;
    color:white;

    padding:12px;

    border-radius:10px;

    margin-bottom:15px;

    text-align:center;

}

.register{

    margin-top:20px;
    text-align:center;
    color:white;

}

.register a{

    color:yellow;
    text-decoration:none;
    font-weight:bold;

}

</style>
</head>
<body>

<div class="login-box">

    <div class="logo">

        <i class="fa-solid fa-user-lock"></i>

        <h1>LOGIN</h1>

        <p>SMK N 1 SANDEN</p>

    </div>

    <?php if(isset($error)) { ?>

        <div class="error">
            <?= $error; ?>
        </div>

    <?php } ?>

    <form method="POST">

        <div class="input-box">

            <i class="fa-solid fa-user"></i>

            <input type="text"
            name="username"
            placeholder="Masukkan Username"
            required>

        </div>

        <div class="input-box">

            <i class="fa-solid fa-lock"></i>

            <input type="password"
            name="password"
            placeholder="Masukkan Password"
            required>

        </div>

        <button type="submit"
        name="login"
        class="btn-login">

            <i class="fa-solid fa-right-to-bracket"></i>
            Login

        </button>

    </form>

    <div class="register">

        Belum punya akun?
        <a href="register.php">Daftar</a>

    </div>

</div>

</body>
</html>