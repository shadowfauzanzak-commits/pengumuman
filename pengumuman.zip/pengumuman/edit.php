<?php
session_start();

if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    die("Akses ditolak!");
}

include "koneksi.php";
?>
<?php
include 'koneksi.php';

$id = $_GET['id'];

$query = mysqli_query($koneksi, "SELECT * FROM pengumuman WHERE id='$id'");

$data = mysqli_fetch_assoc($query);

if(isset($_POST['update'])){

    $judul = $_POST['judul'];
    $isi = $_POST['isi'];

    mysqli_query($koneksi, "
        UPDATE pengumuman 
        SET judul='$judul', isi='$isi'
        WHERE id='$id'
    ");

    header("Location:index.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Pengumuman</title>

    <style>
        body{
            font-family:Arial;
            background:#0f172a;
            display:flex;
            justify-content:center;
            align-items:center;
            height:100vh;
            color:white;
        }

        .box{
            background:#1e293b;
            padding:30px;
            border-radius:20px;
            width:400px;
        }

        input, textarea{
            width:100%;
            padding:12px;
            margin-top:10px;
            border:none;
            border-radius:10px;
        }

        button{
            width:100%;
            padding:12px;
            margin-top:15px;
            border:none;
            border-radius:10px;
            background:#8b5cf6;
            color:white;
            cursor:pointer;
        }
    </style>
</head>
<body>

<div class="box">

    <h2>Edit Pengumuman</h2>

    <form method="POST">

        <input type="text" name="judul"
        value="<?php echo $data['judul']; ?>">

        <textarea name="isi" rows="5"><?php echo $data['isi']; ?></textarea>

        <button type="submit" name="update">
            Update
        </button>

    </form>

</div>

</body>
</html>